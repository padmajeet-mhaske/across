package com.example.across.across.web;

import com.example.across.across.dao.AdEnhancer;
import com.example.across.across.service.AdService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.NoSuchElementException;

/**
 * Ad controller who adds values on top of received values
 */
@RestController
@RequestMapping(path = "/ad")
public class AdController {

    @Autowired
    AdService adService;

    public AdController(){

    }

    @RequestMapping(value = "/demo" , method = RequestMethod.POST)
    public @ResponseBody AdEnhancer save(@RequestBody AdEnhancer jsonString) {

        AdEnhancer ad = adService.populateData(jsonString);
        return ad;
    }

    /**
     * Exception handler if NoSuchElementException is thrown in this Controller
     *
     * @param ex
     * @return Error message String.
     */
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(NoSuchElementException.class)
    public String return400(NoSuchElementException ex) {
        return ex.getMessage();

    }
}
