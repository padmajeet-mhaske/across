package com.example.across.across;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcrossApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcrossApplication.class, args);
	}

}
